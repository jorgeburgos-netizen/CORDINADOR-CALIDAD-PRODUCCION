// ============================================================
//  QPMS — Sistema Calidad · Producción
//  Backend: Node.js + Express + sql.js (SQLite en memoria/archivo) + Multer
// ============================================================
const express  = require('express');
const multer   = require('multer');
const cors     = require('cors');
const path     = require('path');
const fs       = require('fs');
const { v4: uuidv4 } = require('uuid');
const initSqlJs = require('sql.js');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Directorios ──────────────────────────────────────────────
const DB_PATH     = path.join(__dirname, 'db', 'qpms.db');
const UPLOADS_DIR = path.join(__dirname, 'uploads');
const DB_DIR      = path.join(__dirname, 'db');
[UPLOADS_DIR, DB_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

// ── sql.js: base de datos ────────────────────────────────────
let db;

function saveDb() {
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

async function initDb() {
  const SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) {
    const buf = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buf);
  } else {
    db = new SQL.Database();
  }

  db.run(`
    CREATE TABLE IF NOT EXISTS alerts (
      id          TEXT PRIMARY KEY,
      pieza       TEXT NOT NULL,
      colada      TEXT,
      tipo        TEXT,
      decision    TEXT NOT NULL,
      cat         TEXT NOT NULL,
      op          TEXT,
      desc        TEXT NOT NULL,
      accion      TEXT,
      status      TEXT DEFAULT 'pending',
      fecha       TEXT NOT NULL,
      respuesta   TEXT,
      tiempo_resp REAL,
      fecha_resp  TEXT,
      resp_op     TEXT
    );
    CREATE TABLE IF NOT EXISTS photos (
      id        TEXT PRIMARY KEY,
      alert_id  TEXT NOT NULL,
      filename  TEXT NOT NULL,
      mimetype  TEXT,
      created   TEXT NOT NULL
    );
  `);
  saveDb();
}

// ── Helpers DB ────────────────────────────────────────────────
function dbAll(sql, params = []) {
  try {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) rows.push(stmt.getAsObject());
    stmt.free();
    return rows;
  } catch(e) { return []; }
}

function dbGet(sql, params = []) {
  const rows = dbAll(sql, params);
  return rows[0] || null;
}

function dbRun(sql, params = []) {
  db.run(sql, params);
  saveDb();
}

function getAlertWithPhotos(id) {
  const a = dbGet('SELECT * FROM alerts WHERE id = ?', [id]);
  if (!a) return null;
  a.photos = dbAll('SELECT * FROM photos WHERE alert_id = ? ORDER BY created ASC', [id]);
  // Convertir tiempo_resp a número
  if (a.tiempo_resp !== undefined && a.tiempo_resp !== null) a.tiempo_resp = parseFloat(a.tiempo_resp);
  return a;
}

// ── Multer ────────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, uuidv4() + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    cb(null, /^image\/(jpeg|jpg|png|gif|webp|heic)$/i.test(file.mimetype));
  }
});

// ── Middlewares ───────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(UPLOADS_DIR));

// ── Utilidades ────────────────────────────────────────────────
function nowStr() {
  const d = new Date(), p = n => String(n).padStart(2,'0');
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

// ============================================================
//  API REST
// ============================================================

// GET /api/alerts
app.get('/api/alerts', (req, res) => {
  const rows = dbAll(`
    SELECT * FROM alerts
    ORDER BY
      CASE status WHEN 'pending' THEN 0 WHEN 'inprocess' THEN 1 ELSE 2 END,
      fecha DESC
  `);
  res.json(rows.map(a => {
    a.photos = dbAll('SELECT * FROM photos WHERE alert_id = ? ORDER BY created ASC', [a.id]);
    if (a.tiempo_resp !== null && a.tiempo_resp !== undefined) a.tiempo_resp = parseFloat(a.tiempo_resp);
    return a;
  }));
});

// GET /api/alerts/:id
app.get('/api/alerts/:id', (req, res) => {
  const row = getAlertWithPhotos(req.params.id);
  if (!row) return res.status(404).json({ error: 'No encontrada' });
  res.json(row);
});

// POST /api/alerts
app.post('/api/alerts', upload.array('photos', 10), (req, res) => {
  const { pieza, colada, tipo, decision, cat, op, desc, accion } = req.body;
  if (!pieza || !decision || !cat || !desc)
    return res.status(400).json({ error: 'Faltan campos obligatorios: pieza, decision, cat, desc' });

  const id    = 'NCA-' + String(Date.now()).slice(-6);
  const fecha = nowStr();

  dbRun(`INSERT INTO alerts (id,pieza,colada,tipo,decision,cat,op,desc,accion,status,fecha)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [id, pieza, colada||'—', tipo||'—', decision, cat, op||'Calidad', desc, accion||'—', 'pending', fecha]);

  if (req.files && req.files.length) {
    req.files.forEach(f => {
      dbRun('INSERT INTO photos (id,alert_id,filename,mimetype,created) VALUES (?,?,?,?,?)',
        [uuidv4(), id, f.filename, f.mimetype, nowStr()]);
    });
  }

  res.status(201).json(getAlertWithPhotos(id));
});

// PATCH /api/alerts/:id/respond
app.patch('/api/alerts/:id/respond', (req, res) => {
  const { respuesta, resp_op } = req.body;
  if (!respuesta || !respuesta.trim())
    return res.status(400).json({ error: 'La respuesta no puede estar vacía' });

  const row = dbGet('SELECT * FROM alerts WHERE id=?', [req.params.id]);
  if (!row) return res.status(404).json({ error: 'No encontrada' });

  const start    = new Date(row.fecha.replace(' ','T'));
  const diffHrs  = parseFloat(((Date.now() - start) / 3_600_000).toFixed(2));
  const fechaResp = nowStr();

  dbRun(`UPDATE alerts SET respuesta=?,tiempo_resp=?,fecha_resp=?,resp_op=?,status='resolved' WHERE id=?`,
    [respuesta.trim(), diffHrs, fechaResp, resp_op||'Producción', req.params.id]);

  res.json(getAlertWithPhotos(req.params.id));
});

// PATCH /api/alerts/:id/status
app.patch('/api/alerts/:id/status', (req, res) => {
  const { status } = req.body;
  if (!['pending','inprocess','resolved'].includes(status))
    return res.status(400).json({ error: 'Estado inválido' });
  dbRun('UPDATE alerts SET status=? WHERE id=?', [status, req.params.id]);
  res.json(getAlertWithPhotos(req.params.id));
});

// DELETE /api/alerts/:id
app.delete('/api/alerts/:id', (req, res) => {
  const photos = dbAll('SELECT filename FROM photos WHERE alert_id=?', [req.params.id]);
  photos.forEach(p => {
    const fp = path.join(UPLOADS_DIR, p.filename);
    if (fs.existsSync(fp)) fs.unlinkSync(fp);
  });
  dbRun('DELETE FROM photos WHERE alert_id=?', [req.params.id]);
  dbRun('DELETE FROM alerts WHERE id=?', [req.params.id]);
  res.json({ ok: true });
});

// GET /api/kpis
app.get('/api/kpis', (req, res) => {
  const total    = (dbGet('SELECT COUNT(*) as n FROM alerts') || {n:0}).n;
  const pending  = (dbGet("SELECT COUNT(*) as n FROM alerts WHERE status='pending'") || {n:0}).n;
  const inproc   = (dbGet("SELECT COUNT(*) as n FROM alerts WHERE status='inprocess'") || {n:0}).n;
  const resolved = (dbGet("SELECT COUNT(*) as n FROM alerts WHERE status='resolved'") || {n:0}).n;
  const avgRow   = dbGet("SELECT AVG(tiempo_resp) as avg FROM alerts WHERE tiempo_resp IS NOT NULL");
  const avgResp  = avgRow && avgRow.avg ? parseFloat(parseFloat(avgRow.avg).toFixed(2)) : null;
  const rejected = (dbGet("SELECT COUNT(*) as n FROM alerts WHERE decision='rechazado'") || {n:0}).n;
  const withPhotos = (dbGet("SELECT COUNT(DISTINCT alert_id) as n FROM photos") || {n:0}).n;

  res.json({
    total, pending, inproc, resolved, avgResp, rejected, withPhotos,
    pctResolved: total ? Math.round(resolved/total*100) : 0,
    pctWithPhotos: total ? Math.round(withPhotos/total*100) : 0
  });
});

// Fallback SPA
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// ── Iniciar ───────────────────────────────────────────────────
initDb().then(() => {
  app.listen(PORT, () => {
    console.log(`\n✅  QPMS corriendo en http://localhost:${PORT}`);
    console.log(`   Base de datos: ${DB_PATH}`);
    console.log(`   Fotos:         ${UPLOADS_DIR}\n`);
  });
}).catch(e => { console.error('Error iniciando DB:', e); process.exit(1); });
