# QPMS — Sistema de Alertas Calidad · Producción

Sistema web en tiempo real para registrar piezas objetadas/rechazadas por Calidad,
notificar a Producción y medir tiempos de respuesta entre procesos.

---

## Requisitos previos

- [Node.js 18+](https://nodejs.org) instalado en tu computador
- Cuenta gratuita en [GitHub](https://github.com) (para el despliegue)
- Cuenta gratuita en [Railway](https://railway.app)

---

## Opción A — Correr localmente (prueba en tu PC/red interna)

```bash
# 1. Instalar dependencias
npm install

# 2. Iniciar el servidor
npm start

# 3. Abrir en el navegador
#    http://localhost:3000
```

Todos en tu red WiFi pueden acceder con la IP de tu PC, ej: http://192.168.1.50:3000

---

## Opción B — Despliegue en Railway (acceso desde cualquier lugar con internet)

### Paso 1 — Subir a GitHub

```bash
git init
git add .
git commit -m "QPMS inicial"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/qpms.git
git push -u origin main
```

### Paso 2 — Crear proyecto en Railway

1. Entra a https://railway.app y haz clic en **New Project**
2. Selecciona **Deploy from GitHub repo**
3. Conecta tu cuenta GitHub y elige el repositorio `qpms`
4. Railway detecta automáticamente Node.js y despliega

### Paso 3 — Agregar volumen persistente (para la base de datos y fotos)

> Importante: sin esto los datos se pierden al reiniciar el servidor.

1. En Railway, abre tu proyecto → pestaña **Volumes**
2. Clic en **Add Volume**
3. Mount Path: `/app/db`  → para la base de datos SQLite
4. Repite: Mount Path: `/app/uploads` → para las fotos

### Paso 4 — Obtener la URL pública

1. En Railway → pestaña **Settings** → **Networking**
2. Clic en **Generate Domain**
3. Tu URL será algo como: `https://qpms-production.up.railway.app`

Comparte esa URL con Calidad y Producción. ¡Listo!

---

## Estructura del proyecto

```
qpms/
├── server.js          ← Backend Node.js + API REST
├── package.json
├── railway.toml       ← Configuración de despliegue
├── public/
│   └── index.html     ← Frontend completo (Calidad + Producción)
├── db/                ← Base de datos SQLite (se crea automáticamente)
│   └── qpms.db
└── uploads/           ← Fotos adjuntas (se crean automáticamente)
```

---

## API REST — Endpoints disponibles

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | /api/alerts | Listar todas las alertas |
| GET | /api/alerts/:id | Detalle de una alerta |
| POST | /api/alerts | Crear nueva alerta (multipart/form-data) |
| PATCH | /api/alerts/:id/respond | Producción registra respuesta |
| PATCH | /api/alerts/:id/status | Cambiar estado (pending/inprocess) |
| DELETE | /api/alerts/:id | Eliminar alerta y sus fotos |
| GET | /api/kpis | Métricas del dashboard |

---

## Campos de una alerta

| Campo | Obligatorio | Descripción |
|-------|-------------|-------------|
| pieza | ✅ | Número de parte o pieza |
| decision | ✅ | rechazado / objetado / condicional |
| cat | ✅ | Categoría del defecto |
| desc | ✅ | Descripción detallada |
| colada | — | N° de colada / heat number |
| tipo | — | Tipo de material |
| op | — | Nombre del inspector |
| accion | — | Acción requerida a producción |
| photos | — | Imágenes del defecto (máx 10, 10 MB c/u) |

---

## Próximos pasos sugeridos

- Agregar autenticación con usuario/contraseña por rol
- Notificaciones push o correo cuando llega una nueva alerta
- Exportar reporte PDF mensual de NCRs
- Filtros por fecha, material o decisión en el historial

---

Desarrollado con Node.js · Express · SQLite · Tabler Icons
